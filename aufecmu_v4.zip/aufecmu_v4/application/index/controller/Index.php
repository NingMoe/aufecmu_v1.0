<?php
namespace app\index\controller;
use think\controller;
use think\Request;
use think\Url;
use think\View;

class Index extends controller {

    protected $rule = [
        'name'  =>  'require|max:25|token',
    ];

    public function index() {
        return  $this->fetch("active",[
            'test'=>'test'
        ]);
    }

    public function active() {
        return  $this->fetch("active",[
            'detail'=>url("index/index/active_detail"),
            'auth'=>url("index/index/auth"),
        ]);
    }

    public function active_detail() {
        return  $this->fetch("active_detail",[
            'auth'=>url("index/index/auth_detail"),
        ]);
    }

    /*
     * 用于鉴定用户的信息是否正确的ajax函数接口
     * */
    public function auth() {
        $postData = Request::instance()->post();
        $ru = $this->rule+[
            'sfz' => 'require|min:15|max:18',
            'xm'=>'require'
        ];
        $res=$this->validate($postData,$ru);
        if($res == true) {
            $xs = new \app\index\model\Xs();
            if($xs->isExist(
                array(
                    'name'=>$postData['xm'],
                    'sfz'=>substr($postData['sfz'],-6)
                )
            )) {
                return ['status'=>1,'info'=>'ok'];
            }
            else {
                if($xs->isExist(
                    array(
                        'sfz'=>substr($postData['sfz'],-6)
                    )
                )) {
                    return ['status'=>-3,'info'=>'请填写入学时的姓名'];
                }
                else {
                    return ['status'=>-2,'info'=>'您的账户丢失在遥远的二次元空间，正在为您跳转到自定义注册'];
                }
            }
        }
        else {
            return ['status'=>-1,'info'=>$res];
        }
    }

    /*
     * 用于鉴定用户的信息是否正确的ajax函数接口
     * */
    public function auth_detail() {

    }

}
