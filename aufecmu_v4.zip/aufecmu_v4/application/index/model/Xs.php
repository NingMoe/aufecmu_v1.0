<?php
/**
 * Created by PhpStorm.
 * User: zhengwei
 * Date: 2017/3/29
 * Time: 下午3:47
 */

namespace app\index\model;
use think\model;

class Xs extends model {

    public function getOne() {
        return $this->where(['studentid'=>20142917])->find();
    }

    public function isExist($array) {
        $count = $this->where($array)->count();
        return $count>0;
    }


}

