<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:80:"/Users/zhengwei/www/aufecmu_v4/public/../application/index/view/index/index.html";i:1490718230;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>test</title>
</head>
<body>
tst
</body>
</html>